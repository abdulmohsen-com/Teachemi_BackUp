package com.example.teachemi;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class Atoms extends AppCompatActivity implements java.io.Serializable {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.atoms);
        ImageView image = findViewById(R.id.imageView);
        TextView Mass = findViewById(R.id.atomicMass);
        TextView name = findViewById(R.id.name);
        TextView Num = findViewById(R.id.atomicNum);
        TextView symbol = findViewById(R.id.symbol);
        Button Back = findViewById(R.id.Back);
        final Bundle Airport = getIntent().getExtras();
        Element p = (Element) Airport.getSerializable("Stuff");
        image.setImageResource(p.getImage());
        name.setText(p.getName());
        symbol.setText(p.getSymbol());
        Mass.setText(p.getAtomicMass() +"");
        Num.setText(p.getAtomicNumber() + "");
        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Atoms.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
