package com.example.teachemi;

import java.io.Serializable;

public class Element implements Serializable {
    private String Name;
    private String Symbol;
    private int AtomicNumber;
    private double AtomicMass;
    private int Image;


    public Element(String name, String symbol, int atomicNumber, double atomicMass, int image) {
        Name = name;
        Symbol = symbol;
        AtomicNumber = atomicNumber;
        AtomicMass = atomicMass;
        Image = image;
    }

    public int getImage() {
        return Image;
    }

    public void setImage(int image) {
        Image = image;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getSymbol() {
        return Symbol;
    }

    public void setSymbol(String symbol) {
        Symbol = symbol;
    }

    public int getAtomicNumber() {
        return AtomicNumber;
    }

    public void setAtomicNumber(int atomicNumber) {
        AtomicNumber = atomicNumber;
    }

    public double getAtomicMass() {
        return AtomicMass;
    }

    public void setAtomicMass(double atomicMass) {
        AtomicMass = atomicMass;
    }
}

