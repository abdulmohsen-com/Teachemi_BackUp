package com.example.teachemi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText Search = findViewById(R.id.Search);
        Button Go = findViewById(R.id.Go);
        RecyclerView PT = findViewById(R.id.table);
        System.out.println(PT);
        System.out.println(R.id.table);
        PT.setHasFixedSize(true);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        PT.setLayoutManager(lm);


        final Element H = new Element("Hydrogen", "H", 1, 1.00784, R.drawable.hydrogen);
        final Element O = new Element("Oxygen", "O", 8, 15.999, R.drawable.oxygen);
        final Element He = new Element("Helium", "He", 2, 4.002602, R.drawable.helium);
        final Element Ge = new Element("Germanium", "H", 32, 72.64, R.drawable.germanium);
        final Element U = new Element("Uranium", "U", 92, 238.02891, R.drawable.uranium);
        final Element Li = new Element("Lithium", "Li",3, 6.941, R.drawable.lithium);
        final Element N = new Element("Nitrogen", "N", 7, 14.0067, R.drawable.nitrogen);
        final Element Ne = new Element("Neon", "Ne", 10, 20.1797, R.drawable.neon);
        final Element Na = new Element("Sodium", "Na", 11, 22.9897, R.drawable.sodium);
        final Element Al = new Element("Aluminium", "Al", 13,26.9815, R.drawable.aluminium);
        final Element Ca = new Element("Calcium", "Ca", 20, 40.078, R.drawable.calcium);
        final Element Ti = new Element("Titanium", "Ti", 22, 47.867, R.drawable.titanium);
        final Element Fe = new Element("Iron", "Fe", 26, 55.845, R.drawable.iron);
        final Element Zn = new Element("Zinc", "Zn", 30, 65.39, R.drawable.zinc);
        final Element Kr = new Element("Krypton", "Kr", 36, 83.8, R.drawable.krypton);
        final Element Rh = new Element("Rhodium", "Rh", 45, 102.9055, R.drawable.rhodium);
        final Element In = new Element("Indium", "In", 49, 114.818, R.drawable.indium);
        final Element Sn = new Element("Tin", "Sn", 50, 118.71, R.drawable.tin);
        final Element W = new Element("Tungsten", "W", 74, 183.84, R.drawable.tungsten);
        final Element Pt = new Element("Platinum", "Pt", 78, 195.078, R.drawable.platinum);

        ArrayList<Element> PeriodicTable = new ArrayList<>();
        PeriodicTable.add(H);//1
        PeriodicTable.add(O);//2
        PeriodicTable.add(He);//3
        PeriodicTable.add(Ge);//4
        PeriodicTable.add(U);//5
        PeriodicTable.add(Li);//6
        PeriodicTable.add(N);//7
        PeriodicTable.add(Ne);//8
        PeriodicTable.add(Na);//9
        PeriodicTable.add(Al);//10
        PeriodicTable.add(Ca);//11
        PeriodicTable.add(Ti);//12
        PeriodicTable.add(Fe);//13
        PeriodicTable.add(Zn);//14
        PeriodicTable.add(Kr);//15
        PeriodicTable.add(Rh);//16
        PeriodicTable.add(In);//17
        PeriodicTable.add(Sn);//18
        PeriodicTable.add(W);//19
        PeriodicTable.add(Pt);//20

//        PeriodicTable.get();

        System.out.println(PeriodicTable.size() + " Abdulmohsen");


        PTAdaptor PTA = new PTAdaptor(PeriodicTable, this);
        PT.setAdapter(PTA);

        Go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String SearchBar = Search.getText().toString();
                if (SearchBar.isEmpty()){
                    Toast.makeText(MainActivity.this, "Please Input A Search Request, Then Press The Button.", Toast.LENGTH_SHORT).show();
                }else if (SearchBar == "Hydrogen"){
                    Intent intent = new Intent(MainActivity.this, Atoms.class);
                    intent.putExtra("Project Search", H);
                }
            }
        });

    }

}

